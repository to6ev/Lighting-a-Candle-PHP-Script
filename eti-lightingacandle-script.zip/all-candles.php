<?php
$ip = $_SERVER['REMOTE_ADDR'];
$page = $_SERVER['REQUEST_URI'];
$UserAgent = $_SERVER['HTTP_USER_AGENT'];
date_default_timezone_set("Europe/Sofia");
$date = date("d-m-y|H:i:s");
$in = $date . " - " . $ip . " - " . $page . " - " . $UserAgent . "<br />";
$fopen = fopen("log.html", "a");
fwrite($fopen, $in);
fclose($fopen);
?>

<?php
require('ban-ip.php');
include('config.php');
include('header.php');

if(!fopen(ENTRIES, "r")) { 
	echo "Could not open entries file. Please verify permissions (CHMOD - 666) and actual existence.";
} else {
	if (filesize(ENTRIES) > 0) {

		$entries = file(ENTRIES);
		$count = count($entries);

		$numpages = ceil($count/$perpage);
		if (isset($_GET['page']) && is_numeric($_GET['page'])) $pg = $_GET['page']; else $pg = 1;
		

		if ($perpage < $count) {
			if ($pg > 1 && $pg <= $numpages) {
				$prev = $pg - 1;
				echo '<center><a href="all-candles.php?page='.$prev.'">Prev </a>';
			} else {
				echo "Pages: ";
			}

			for ($x=1; $x<=$numpages; $x++) {
				if ($x == $pg) echo '<strong>'.$x.'</strong> ';
				else echo '<a href="all-candles.php?page='.$x.'">'.$x.'</a> ';
			}
			
			if ($pg < $numpages) {
				$next = $pg + 1;
				echo '<a href="all-candles.php?page='.$next.'"> Next</a>';
			} else {
				echo "Next";
			}
		}
		echo  "</center> \n\n ";

		$i = $perpage * ($pg - 1); 
		$end = $i + $perpage;

		if ($end > $count) $end = $count;
?>
		<div id="entries">
<?php
		while ($i<$end){
			list($name,$odate,$ip,$message) = preg_split("/,(?! )/",$entries[$i]);
			
			$date = date($dateformat, strtotime($odate));
			$message = trim(stripslashes($message), "\"\x00..\x1F");
			$rowColour = $i % 2;
?>

                                        <table>
			                <tr>
                                        <td>
					<img src="icons/candle.gif" alt="Virtual Candle" /><br />
					<?php echo emoticonise(linebreaker($message)); ?><br />
                                        <span class="bold">Name:</span> <?php echo $name; ?><br />
					<span class="bold">Date:</span> <?php echo $date; ?><br />
                                        </td>
                                        </tr>
	                                </table>			


<?php
$i++;
} 
?>
		</div>

<?php
	} else { 
		echo "<p>No entries yet!</p> "; 
	}
}
		echo '<p class="pagination">'.$count.' candles<br />';
@include('footer.php'); ?>

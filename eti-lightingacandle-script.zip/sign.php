<?php
require('ban-ip.php');
$show_form = true;
$error_msg = NULL;

if (isset($_POST['submit']) || $_SERVER['REQUEST_METHOD'] == "POST") {
	require_once('config.php');
	if (isset($captcha) && $captcha == "yes") {
		session_start();
		if(md5($_POST['captcha']) != $_SESSION['key']) {
			setcookie(session_name(), '', time()-36000, '/');
			$_SESSION = array();
			session_destroy();

			include('header.php');
			echo "<p>The digits you entered didn't match the image, please <a href='sign.php'>try again</a></p>";
			include('footer.php');
			exit;
		}
		if (isset($_SESSION['key']) && isset($_COOKIE[session_name()])) {
			setcookie(session_name(), '', time()-36000, '/');
			$_SESSION = array();
			session_destroy();
		}
	}
	include('header.php');

	$ipPattern = '/\b(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/i';
	
	if (filesize(IPBLOCKLIST) > 0) {
		$BlockedIPs = file(IPBLOCKLIST);
		
		foreach($BlockedIPs as $key => $ip)
			$BlockedIPs[$key] = trim($ip);
		
		$iplist = '/(' . implode('|', $BlockedIPs) . ')/';
	}

	if ($floodcontrol == "yes" && filesize(ENTRIES) > 0) {
		$open2check = file(ENTRIES);
		$expodelineone = explode(",", $open2check['0']);
			if ($_SERVER['REMOTE_ADDR'] == $expodelineone['4'])	{
				echo "<p>Sorry, you can't light a candle twice in a row.</p>";
				exit(include('footer.php'));
			}
	}
		
	if (!preg_match($ipPattern, $_SERVER['REMOTE_ADDR']) || (isset($iplist) && preg_match($iplist, $_SERVER['REMOTE_ADDR']))) {
		echo "<p>Your IP is not valid or it has been banned, you cannot light a prayer candle. Sorry!</p>\n\n";
		exit(include('footer.php'));
	}

	// check bot 
	checkBots();
	
	if (isset($allowlinks) && $allowlinks == "no" && (substr_count($_POST['comments'], 'http://') > 0 || substr_count($_POST['comments'], 'URL=') > 0)) {
		echo "<p>Your message contains URLs. To cut down on spam, the posting of URLs/Links has been disabled. \n</p>";
		exit(include('footer.php'));
	}
	
	// spam words
	if (filesize(SPAMWORDS) > 0) {
		$spamlist = file(SPAMWORDS);
		
		foreach($spamlist as $key => $spamword)
			$spamlist[$key] = trim($spamword);

		$SpamWords = '/(' . implode('|', $spamlist) . ')/i';
	}

	// check for javascript exploits, spam
	$exploits = "/(content-type|bcc:|cc:|document.cookie|onclick|onload|javascript|alert)/i";
	foreach ($_POST as $key => $val) {
		if (isset($SpamWords) && preg_match($SpamWords, urldecode($val))) {
			echo "<p>Your message contains words in the spam list, please go back and remove references to obvious 'spam' material. \n</p>";
			exit(include('footer.php'));
		}
		if (preg_match($exploits, $val)) {
			echo "<p>No meta injection! \n</p>";
			exit(include('footer.php'));
		}
		
		$c[$key] = cleanUp($val);
	}

	// checks:)
	$error_msg = NULL;
	if (!empty($c['human'])) {
		$error_msg .= "Spam detection tells me you're not human.";	
	} elseif (empty($c['name']) || strlen($c['name']) > 15) {
		$error_msg .= "Name is a invalid! It must not be blank, must have no special characters, must not exceed 15 characters!";
	} elseif (empty($c['comments']) || strlen($c['comments']) < 7) {
		$error_msg .= "Your prayer is too short. Must be min 7 symbols.";
	}
	
	if ($error_msg == NULL) {
		$show_form = false;

		$c['name'] = ucwords(strtolower($c['name']));

		$c['comments'] = str_replace("<br /><br /><br /><br />", "<br /><br />", preg_replace("/,(?! )/", ", ", preg_replace("([\r\n])", "<div>", $c['comments'])));
		
		$signdate = date("Y-m-d H:i:s");

		
		$entryformat = $c['name'].",".$signdate.",".$_SERVER['REMOTE_ADDR'].',"'.$c['comments'].'"'."\r\n";

		if ($moderate == "yes") light_candle(TEMPENTRIES, $entryformat);
		else light_candle(ENTRIES, $entryformat);
	}
      }
if (!isset($_POST['submit']) || $show_form == true) {
	require_once('config.php');
	include_once('header.php');

	function get_data($var) {
		if (isset($_POST[$var])) echo cleanUp($_POST[$var]);
	}

?>

<center><p>Light a candle</p></center>

<?php
	if ($error_msg != NULL) {
		echo '<p><strong style="color: red;">ERROR:</strong><br />'.$error_msg.'</p>';
	}
?>

<script language="javascript">
    function changeImage() {

        if (document.getElementById("imgClickAndChange").src == "icons/candle-big-off.jpg")
        {
            document.getElementById("imgClickAndChange").src = "icons/candle-big-off.jpg";
        }
        else 
        {
            document.getElementById("imgClickAndChange").src = "icons/candle.gif";
        }
    }
    
document.write("Click on the candle and fill the fields");

function insertText(elemID, text)
      {
        var elem = document.getElementById(elemID);
        elem.innerHTML += text;
      }
</script>

<form action="sign.php" method="post">
<p class="hidden">
<input type="checkbox" name="human" id="human" /> <label for="human">:)</label>
</p>

<p>
<a href="#light"><img alt="" src="icons/candle-big-off.jpg" title="Light a Candle" id="imgClickAndChange" onclick="changeImage()"/></a>
</p>

<p>
        <label for="name">Name <small>(required)</small></label><br />
	<input type="text" name="name" id="name" maxlength="15" value="<?php get_data("name"); ?>" /><br /><br />
        <label for="comments">Your Prayer <small>(write to your native lang)</small></label><br />
<small><img src="icons/virtualcandle.gif" onclick="insertText('comments', ' :candle: ');">:candle: <img src="icons/redcandle.gif" onclick="insertText('comments', ' :redc: ');">:redc: <img src="icons/longcandle.gif" onclick="insertText('comments', ' :longc: ');">:longc: <img src="icons/smallcandle.gif" onclick="insertText('comments', ' :smallc: ');">:smallc: <img src="icons/crystalcandle.gif" onclick="insertText('comments', ' :crystalc: ');">:crystalc: <img src="icons/2candles.jpg" onclick="insertText('comments', ' :2c: ');">:2c: <img src="icons/redsmallcandle.gif" onclick="insertText('comments', ' :rsc: ');">:rsc:</small>

<br />
	<textarea name="comments" id="comments" onKeyPress="return charLimit(this)" onKeyUp="return characterCount(this)"><?php get_data("comments"); ?></textarea><br />
        <strong><span id="charCount">500</span></strong> from 500 allowable characters<br />
	<?php if (isset($captcha) && $captcha == "yes") { ?><br />
        <label for="captcha">Enter these digits, please.</label><br />
	<img src="captcha.php" alt="" style="margin-bottom: 2px;" /><br />
	<input type="text" name="captcha" id="captcha" maxlength="7" style="width:100px;" /><br />
	<?php } ?>
	<input type="submit" id="submit" name="submit" style="width:110px; height:35px" value="Put a Candle" />
</p>
</form>

<?php
}
include('footer.php'); ?>

<?php 
// simple ip ban system with array
$deny = array(
// put ip or domain here to block evil guests
"http://www.name-of-website.com", 
"www.name-of-website.com", 
"name-of-website.com",
"10.10.13.1",
"10.10.13.",
// "127.0.0.1",  // if you want test to localhost
// and below by this way other ip or domain ... with comma to the end:)



);

if (in_array ($_SERVER['REMOTE_ADDR'], $deny)) {
   header("location: http://google.bg"); // you can redirect to other website
   exit();
} 

?>

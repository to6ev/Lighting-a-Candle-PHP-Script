<?php
// with this php file we delete the log, but only the info and not log.html file
$del = fopen ("log.html", "w+");
fclose($del);
echo "it's done!";
?>

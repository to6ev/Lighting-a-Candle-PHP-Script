<?php

require_once('prefs.php');

define("ENTRIES", "entries.html");
define("TEMPENTRIES", "tempentries.txt");
define("IPBLOCKLIST", "iplist.txt");
define("SPAMWORDS", "spamwords.txt");


function cleanUp($text) {
	$text = trim(htmlentities(strip_tags(urldecode($text))));
	return $text;
}

// break ... upto 30 characters for layout preservation
function linebreaker($text) {
	$new_text = '';
	$text_1 = explode('>',$text);
	$sizeof = sizeof($text_1);
	for ($i=0; $i<$sizeof; ++$i) {
		$text_2 = explode('<',$text_1[$i]);
		if (!empty($text_2[0])) {
			$new_text .= preg_replace('#([^\s .]{30})#i', '\\1  ', $text_2[0]);
		}
		if (!empty($text_2[1])) {
			$new_text .= '<' . $text_2[1] . '>';   
		}
	}
	return $new_text;
}

function doAdminHeader() {
	global $stylecolor;
?>

	<html>
	<head>
		<title>.::Admin Control Panel::.</title>
	</head>
        <body bgcolor="#E6E6FA">

	<div id="container">
	<p id="topnav"><a href="all-candles.php" target="_blank">|View All Candles</a>||<a href="admin.php">Admin|</a></p>
<?php
}
function doAdminFooter() {
	echo "\r\n</div>\r\n</body>\r\n</html>";
}


function blanklinefix($inputfile) {
	ignore_user_abort(true);
	$content = file($inputfile);

	if (count($content) > 0) {
		$content = array_diff(array_diff($content, array("")), array("\r\n"));

		$newContent = array();
		foreach ($content as $line) {
			$newContent[] = trim($line);
		}
		$newContent = implode("\r\n", $newContent);
	
		$fl = fopen($inputfile, "w+");
		if (flock($fl, LOCK_EX)) {
			fwrite($fl, $newContent);
			flock($fl, LOCK_UN);
		} else {
			echo 'The file: '.$inputfile.' could not be locked for writing...';
		}
		fclose($fl);
	}
	ignore_user_abort(false);
}

function doWrite($file2open, $data, $writetype) {
	$file = fopen($file2open, $writetype) or die("ERROR: could not open ".$file2open);
	if (flock($file, LOCK_EX)) {
		fwrite($file, $data);
		flock($file, LOCK_UN);
	} else {
		exit("ERROR: could not lock ".$file2open);
	}
	fclose($file);
}

function light_candle($file, $entry) {	
	$oldData = file_get_contents($file);
	doWrite($file, $entry, "w"); // write the new data
	doWrite($file, $oldData, "a"); // append the old data

	echo "<center><p>Your Candle is lit. God will hear your prayer!</p><br /><a href='all-candles.php'>See your Virtual Candle</a></center>";

	if ($file === TEMPENTRIES)
		echo "<p>Moderation is enabled and the owner will have to approve your Prayer before it appears.</p>";
}

function emoticonise($message) {
	global $emoticons;
		$path_to_emoticons = "icons/";

	if (isset($emoticons) && $emoticons == "yes") {
		$emoticonsA = array(
			':candle:'      => 'virtualcandle.gif',
			':redc:'        => 'redcandle.gif',
			':longc:'       => 'longcandle.gif',
			':smallc:'      => 'smallcandle.gif',
			':crystalc:'    => 'crystalcandle.gif',
			':rsc:'         => 'redsmallcandle.gif',
			':2c:'          => '2candles.jpg',
			
		);
		foreach ($emoticonsA as $key => $value) {
			$message = str_replace($key, " <img src='".$path_to_emoticons.$value."' alt='$key' title='$key' />", $message);
		}
		return $message;
	} else {
		return $message;
	}
}

function checkBots() {
	$isbot = false;
	
	$bots = array("Indy", "Blaiz", "Java", "libwww-perl", "Python", "OutfoxBot", "User-Agent", "PycURL", "AlphaServer", "T8Abot", "Syntryx", "WinHttp", "WebBandit", "nicebot");
	foreach ($bots as $bot)
		if (strpos($_SERVER['HTTP_USER_AGENT'], $bot) !== false)
			$isbot = true;

	if (empty($_SERVER['HTTP_USER_AGENT']) || $_SERVER['HTTP_USER_AGENT'] == " ")
		$isbot = true;
	
	if ($isbot === true) {
		echo "<p>Safety checks indicate there's a high probability that you're a bot, and bots aren't allowed to submit links.</p>";
		exit(include('footer.php'));
	}
}



function countcontents($fileloc) {

	if (filesize($fileloc) > 0) return count(file($fileloc));
	else return 0;
}
blanklinefix(ENTRIES);
blanklinefix(TEMPENTRIES);
blanklinefix(IPBLOCKLIST);
blanklinefix(SPAMWORDS);

error_reporting(0);
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
<title>Light a Virtual Candle Online</title>
<LINK REL="SHORTCUT ICON" href="icons/-candle.gif">
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<meta http-equiv="content-type" content="text/html; charset=windows-1251">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-15" />
<META NAME="ROBOTS" CONTENT="INDEX, FOLLOW">
<META NAME="REVISIT-AFTER" CONTENT="2 DAYS">
<meta name="author" content="www.eti.pw">
<meta name='keywords' content="light a candle, virtual candle, light a virtual candle, light a candle online, prayer candle, запали виртуална свещ, виртуална свещ, виртуална молитва, запали свещ, виртуална църква, виртуален параклис, виртуален храм, виртуален божи храм, онлайн параклис, виртуална черква, virtual chapel, virtual church, зажженную свечу, zapali virtualna svesht, page where people could light a virtual memorial candle, light virtual candle, light a candle script, light a candle php script, candle, candle script, virtual candle script" />
<meta name='description' content="Light a Virtual Candle for a prayer, Birthday, Anniversary, Healing, Birth, Death, Friendship, God's Forgiveness or any occasion" />
<link href="black-stylesheet.css" rel="stylesheet" type="text/css" />

</head>
<body>

<a href="sign.php"><img src="icons/candle-flickering.gif" alt="Ligh a Virtual Candle" /><br />Light a prayer candle</a><br />
<?php
require('ban-ip.php');
$ip = $_SERVER['REMOTE_ADDR'];
$proxy = $_SERVER["HTTP_X_FORWARDED_FOR"];
$page = $_SERVER['REQUEST_URI'];
$UserAgent = $_SERVER['HTTP_USER_AGENT'];
date_default_timezone_set("Europe/Sofia");
$date = date("d-m-y|H:i:s");
$in = $date . " - " . $ip . "=>" . $proxy . " - " . $page . " - " . $UserAgent . "<br />";
$fopen = fopen("log.html", "a");
fwrite($fopen, $in);
fclose($fopen);
?>
<p style="position: fixed; bottom: 0; width:100%; text-align: center">
<small>Regardless of what your religion is or what you believe, you can light a candle for a prayer, for your health, birthday, healing, birth, death, friendship, forgiveness or for praise of God's Glory. Let God be with You!</small>
</p>
</body>
</html>
<!-- † www.eti.pw † -->

<?php
$title = "Light a Virtual Candle"; // set your title here - <title> tag
$admin_sitename = "Homepage";   // your website name or just homepage - used in the footer
$admin_name	= "admin";   // admin username - don't forget to change this!
$admin_pass	= "admin";   // admin password - don't forget to change this!
$secret = "changeme";    // this is like a second password:) don't forget to change this!
$admin_url = "./";   // your website url - used in da footer - footer.php file
$emoticons = "yes";   // convert text emoticons - write yes or no
$dateformat	= "d M y h:ia";   // date format
$stylecolor	= "black";   // about css file - you can create own theme with other css file
$perpage = "20";   // pagination - how many entries per page
$captcha = "yes";   // captcha on? - write yes or no
$floodcontrol = "no";   // allow flood control? - write yes or no
$allowlinks = "no";   // allow URLs in a Prayer? - in field 'Your Prayer'
$moderate = "no";   // new entries have to be approved first - write yes or no | i suggest you to leave it with 'no'
?>

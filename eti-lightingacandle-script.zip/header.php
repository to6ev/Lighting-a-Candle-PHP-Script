<?php
$ip = $_SERVER['REMOTE_ADDR'];
$proxy = $_SERVER["HTTP_X_FORWARDED_FOR"];
$page = $_SERVER['REQUEST_URI'];
$UserAgent = $_SERVER['HTTP_USER_AGENT'];
date_default_timezone_set("Europe/Sofia");
$date = date("d-m-y|H:i:s");
$in = $date . " - " . $ip . "=>" . $proxy . " - " . $page . " - " . $UserAgent . "<br />";
$fopen = fopen("log.html", "a");
fwrite($fopen, $in);
fclose($fopen);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="en" xml:lang="en">
<head>
<title><?php echo $title; ?></title>
<LINK REL="SHORTCUT ICON" href="icons/-candle.gif">
<meta http-equiv="content-type" content="text/html; charset=utf-8">
<meta http-equiv="content-type" content="text/html; charset=windows-1251">
<meta http-equiv="Content-Type" content="text/html; charset=cp-1251">
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-15" />
<META NAME="ROBOTS" CONTENT="INDEX, FOLLOW">
<META NAME="REVISIT-AFTER" CONTENT="2 DAYS">
<meta name="author" content="brigante">
<meta name='keywords' content="light a candle, virtual candle, light a virtual candle, light a candle online, prayer candle, запали виртуална свещ, виртуална свещ, виртуална молитва, запали свещ, виртуална църква, виртуален параклис, виртуален храм, виртуален божи храм, онлайн параклис, виртуална черква, virtual chapel, virtual church, зажженную свечу, zapali virtualna svesht, page where people could light a virtual memorial candle, light virtual candle, light a candle script, light a candle php script, candle, candle script, virtual candle script" />
<meta name='description' content="Light a Virtual Candle for a prayer, birthday, anniversary, healing, birth, death, friendship or any occasion" />

<link href="<?php echo $stylecolor; ?>-stylesheet.css" rel="stylesheet" type="text/css" />
<style type="text/css">
#arrowUp {
  position: fixed;
  height: auto;
  width: auto;
  right: 10px;
  bottom: 10px;
  font-size: 32px;
}
#arrowUp a {
  text-decoration: none;
  color: orange;
  font-weight: bold;
  font-family: serif;
}
</style>

<script type="text/javascript">
var maxLength=500;
function charLimit(el) {
    if (el.value.length > maxLength) return false;
    return true;
}
function characterCount(el) {
    var charCount = document.getElementById('charCount');
    if (el.value.length > maxLength) el.value = el.value.substring(0,maxLength);
    if (charCount) charCount.innerHTML = maxLength - el.value.length;
    return true;
}
</script>

</head>
<body>

<script type="text/javascript">
var appended = false, bookmark = document.createElement("div");
bookmark.id = "arrowUp";
bookmark.innerHTML = "<a href=\"#\" title=\"On Top\">&uarr;<\/a>";
 
onscroll = function() {
  var scrollTop = document.documentElement.scrollTop || document.body.scrollTop;
  if (scrollTop > 500) {
    if (!appended) {
      document.body.appendChild(bookmark);
      appended = true;
    }
  } else {
    if (appended) {
      document.body.removeChild(bookmark);
      appended = false;
    }
  }
};
</script>

<div id="container">

<p id="topnav"><a href="sign.php">Light a Candle</a> | <a href="all-candles.php">View All Burning Candles</a></p>

<?php
$ip = $_SERVER['REMOTE_ADDR'];
$page = $_SERVER['REQUEST_URI'];
$UserAgent = $_SERVER['HTTP_USER_AGENT'];
date_default_timezone_set("Europe/Sofia");
$date = date("d-m-y|H:i:s");
$in = $date . " - " . $ip . " - " . $page . " - " . $UserAgent . "<br />";
$fopen = fopen("log.html", "a");
fwrite($fopen, $in);
fclose($fopen);
?>

<?php
require('ban-ip.php');
require('config.php');

if (isset($_COOKIE['eti'])) {
	if ($_COOKIE['eti'] == md5($admin_pass.$secret)) {
		if (isset($_GET['p'])) $page = $_GET['p'];
		else $page = NULL;
		
		if (!isset($_GET['file']) || (isset($_GET['file']) && ($_GET['file'] != "entries.html" && $_GET['file'] != "tempentries.txt")))
			$_GET['file'] = null;
		
		doAdminHeader();
		switch($page) {
		case "manageentries":
			echo "<p style='color: red;'><strong>Delete Entries:</strong></p> \n\n";
			if (filesize($_GET['file']) > 0) {

				$entries = file($_GET['file']);
				$count = count($entries);

				echo '<p style="text-align: center;">'.$count.' entries | ';
				$numpages = ceil($count/$perpage);

				echo "pages: ";
				for ($x=1; $x<=$numpages; $x++) {
					if (isset($_GET['page']) && $x == $_GET['page'] || (!isset($_GET['page']) &&  $x == 1))
						echo '<strong>'.$x.'</strong>';
					else
						echo '<a href="admin.php?p=manageentries&amp;file=entries.html&amp;page='.$x.'">'.$x.'</a> ';
				}
				echo  "</p> \n\n ";
	
				if (isset($_GET['page']) && is_numeric($_GET['page'])) $i = $perpage * ($_GET['page'] - 1);
				else $i = 0;

				$end = $i + $perpage;
	
				if ($end > $count) $end=$count;
?>
				<form action="admin.php?p=appentries" method="post">
				<table>
<?php
				while ($i < $end) {
					list($name,$date,$ip,$message) = preg_split("/,(?! )/", $entries[$i]);
					
					$message = trim(stripslashes($message), "\"\x00..\x1F");

?>
					<tr>
						<td>
							<input type="hidden" name="hashy" id="hashy" value="<?php echo md5(date("H").$secret); ?>">

							<strong>Name:</strong> <?php echo $name; ?><br>
		
							<strong>Date:</strong> <?php echo date($dateformat, strtotime($date)); ?><br>
							<strong>IP:</strong> <a href="http://whatismyipaddress.com/ip/<?php echo $ip; ?>" target="_blank" title="View Info about this IP"><?php echo $ip; ?></a><br>
							<br>
							<a href="admin.php?p=editentry&amp;entry=<?php echo $i; ?>&amp;file=<?php echo $_GET['file']; ?>">Edit Entry</a><br>
							<a href="admin.php?p=delentry&amp;entry=<?php echo $i; ?>&amp;file=<?php echo $_GET['file']; ?>" onclick="javascript:return confirm('Are you sure you want to delete this entry?')">Delete Entry</a><br><br />
							<?php if ($_GET['file'] == "tempentries.txt") : ?>
							<input type="checkbox" class="check" name="appr[<?php echo $i; ?>]" value="<?php echo $i; ?>"> Approve
							<?php endif; ?>
						</td>
						<td>
							<?php echo $message; ?>
						</td>
					</tr>
<?php
					$i++;
				}
?>
				</table>
				<?php if ($_GET['file'] == "tempentries.txt") : ?>
					<p><input type="submit" name="submit" id="submit" value="Approve"></p>
				<?php endif; ?>
				</form>
<?php
			} else {
				echo "<p>No entries to manage!</p>";
			}
		break;
		case "appentries":
			if (!isset($_POST['hashy']) || $_POST['hashy'] != md5(date("H").$secret)) exit("<p>Invalid hashy token</p>");
			
			if (isset($_POST['appr']) && is_array($_POST['appr'])) {
				$pending = file(TEMPENTRIES);
				$approved = array();
				
				foreach ($_POST['appr'] as $entry => $id) {
					if (is_numeric($id) && array_key_exists($id, $pending)) {
						$approved[] = $pending[$id];
						unset($pending[$id]);
					}
				}
				$pending = implode("", $pending);
				doWrite(TEMPENTRIES, $pending, "w");
				
				$newentries = implode("", $approved) . "\r\n";
				light_candle(ENTRIES, $newentries);
				
				echo "<p>Selected entries - approved</p>";
			}
		break;
		case "editentry":
			if ($_SERVER['REQUEST_METHOD'] == "POST") {
				if (!isset($_POST['hashy']) || $_POST['hashy'] != md5(date("H").$secret)) exit("<p>Invalid hashy token.</p>");
				
				foreach ($_POST as $key => $val) {
					$$key = cleanUp($val);
				}
				$comments = str_replace("<br /><br /><br /><br />", "<br /><br />", preg_replace("/,(?! )/", ", ", preg_replace("([\r\n])", "<br />", $comments)));

				$editedEntry = $name . "," . $date . "," . $ip . "," . "\"$comments\"" . "\n";
				
				$entries = file($file);
				$entries[$gbentry] = $editedEntry;
				$entries = trim(implode($entries));

				doWrite($file, $entries, "w");

				echo '<p>Entry edited. <a href="admin.php">Return to Admin</a> | <a href="admin.php?p=manageentries&amp;file='.$file.'">manage more</a>?</p>';
				exit(doAdminFooter());
			}
			echo "<p>Note: editing an entry that is in moderation will not approve it... you must do this separately</p>";

			if (!isset($_GET['entry']) || $_GET['entry'] == "" || !is_numeric($_GET['entry'])) {
				echo "<h4>Error</h4>\r\n<p>You didn't select a valid entry.</p>";
				exit(include('footer.php'));
			} elseif (!isset($_GET['file']) || $_GET['file'] == "" || !file_exists($_GET['file'])) {
				echo "<h4>Error</h4>\r\n<p>You didn't select a valid file.</p>";
				exit(include('footer.php'));
			}
			$entries = file($_GET['file']);

			list($name,$odate,$ip,$message) = preg_split("/,(?! )/", $entries[$_GET['entry']]);
			

			$message = str_replace("<br /><br />", "\r\n\r\n", trim(stripslashes($message), "\"\x00..\x1F"));
?>
			<form action="admin.php?p=editentry" method="post">
			<p>
				<input type="hidden" name="hashy" id="hashy" value="<?php echo md5(date("H").$secret); ?>">
				<input type="hidden" name="gbentry" id="gbentry" value="<?php echo $_GET['entry']; ?>">
				<input type="hidden" name="file" id="file" value="<?php echo $_GET['file']; ?>">
			
				<input type="text" name="name" id="name" value="<?php echo $name; ?>" /> <label for="name">Name</label><br>
				<input type="text" name="date" id="date" value="<?php echo $odate; ?>" /> <label for="date">Date/Time</label> <small>(yyyy-mm-dd)</small><br>
				<input type="text" name="ip" id="ip" value="<?php echo $ip; ?>" readonly="readonly" /> <label for="ip">IP Address</label><br>
				<textarea name="comments" id="comments"><?php echo $message; ?></textarea> <br>
				
				<input type="submit" id="submit" value="Edit" />
			</p>
			</form>
<?php
		break;
		case "delentry":
			if (!isset($_GET['entry']) || $_GET['entry'] == "" || !is_numeric($_GET['entry'])) {
				echo "<h4>Error</h4>\r\n<p>You didn't select a valid entry.</p>";
				exit(include('footer.php'));
			} elseif (!isset($_GET['file']) || $_GET['file'] == "" || !file_exists($_GET['file'])) {
				echo "<h4>Error</h4>\r\n<p>You didn't select a valid file.</p>";
				exit(include('footer.php'));
			}
			
			$entries = file($_GET['file']);
			unset($entries[$_GET['entry']]);
			$entries = implode("", $entries);
			$entries = trim($entries);

			doWrite($_GET['file'], $entries, "w");

			echo '<p>Entry deleted. <a href="admin.php">Return to admin</a> / <a href="admin.php?p=manageentries&amp;file='.$_GET['file'].'">Delete more?</a></p>';
		break;
                case"editlog"
		
?>
		        <h4><a href="log.html" target="_blank">View Log</a></h4>
			<h4><a href="dlog.php" target="_blank">Delete Log</a></h4>	
	
<?php
		break;
		case "editip":
			if ($_SERVER['REQUEST_METHOD'] == "POST") {
				if (isset($_POST['ip']) && is_array($_POST['ip'])) {
					$existing = file(IPBLOCKLIST);
					
					foreach ($_POST['ip'] as $ipadd)
						if (preg_match("^((\d|[1-9]\d|2[0-4]\d|25[0-5]|1\d\d)(?:\.(\d|[1-9]\d|2[0-4]\d|25[0-5]|1\d\d)){3})$^", $ipadd))
							$existing[] = $ipadd;
					
					$new = implode("\r\n", $existing);
					doWrite(IPBLOCKLIST, $new, "w");
					echo "<p>IP added</p>";
				}
				exit(doAdminFooter());
			}
?>


			<form action="admin.php?p=editip" method="post">
			
<p style='color: red;'>Ban IP for flood/spam/other reason:<p>
When you add some IP in iplist.txt file, then you block this bot or human only for posting in 'Your Prayer' field. That mean you block only entries of the evil bot/human and not him as whole to access to your website.<br />
				<br>Only IP:<input type="text" name="ip[]" maxlength="15">
			
<?php
				$ipadds = file(IPBLOCKLIST);
				foreach ($ipadds as $ip)
?>

<input type="submit" name="submit" id="submit" value="Add"> <small>to iplist.txt file</small><br />
<br>If you want to ban some IP/Domain, then open ban-ip.php file and add IP or Domain there in the array... This will block as whole the access of the evil IP/Domain to your website!
			
			</form>
<hr>
<b>all blocked about flood/other (you decide) reason:</b><br><? foreach ($ipadds as $ip) echo "$ip<br>"; ?>
<br /><b>all blocked as whole to access to your site are:</b><br><? foreach ($deny as $deny) echo "$deny<br>"; ?>		

<?php
		break;
		default:
?>
			<ul>
			<li><a href="admin.php?p=manageentries&amp;file=entries.html">Manage Approved Entries</a> (<?php echo countcontents(ENTRIES); ?>)</li>
			<?php if ($moderate == "yes") { ?>
				<li><a href="admin.php?p=manageentries&amp;file=tempentries.txt">Manage Pending Entries</a> (<?php echo countcontents(TEMPENTRIES); ?>)</li>
			<?php } ?>
			</ul>
			
			<ul>
			<li><a href="admin.php?p=editip">Ban IP</a></li>
			<li><a href="admin.php?p=editlog">Manage Log [View/Delete]</a></li>
			<li><a href="ip.txt" target="_blank">View WebCounter's IP Log </a> <small>(Don't delete this log, because the webcounter count from this ip.txt text file :) well, this is <a href="https://en.wikipedia.org/wiki/KISS_principle" target="_blank">KISS principle project :)</a></small></li>
			<li><a href="spamwords.txt" target="_blank">View SpamWords List </a> <small>(You can add other words in the list, just open spamwords.txt file)</small></li>
			</ul>


<?php
		break;
		}
		doAdminFooter();
		exit;
	} else {
		exit("<p>Bad cookie! Delete Private Data... from your Browser! And You will see Admin Area.</p>");
	}
}

if (isset($_GET['p']) && $_GET['p'] == "login") {
	if ($_POST['name'] != $admin_name || $_POST['pass'] != $admin_pass) {
		doAdminHeader();
?>
			<p>Wrong Username/Password</p>

		    <form method="post" action="admin.php">
		    Username:<br>
		    <input type="text" name="name"><br>
		    Password:<br>
		    <input type="password" name="pass"><br>
		    <input type="submit" name="submit" value="Login">
		    </form>
<?php
		doAdminFooter();
		exit;
	} else if ($_POST['name'] == $admin_name && $_POST['pass'] == $admin_pass) {
		setcookie('eti', md5($_POST['pass'].$secret), time()+(31*86400));
		header("Location: admin.php");
		exit;
	} else {
		setcookie('eti', NULL, NULL);
		header("Location: admin.php");
		exit;
	}
}
doAdminHeader();
?>
    <form method="post" action="admin.php?p=login">
    <input type="text" name="name"><br>
    <input type="password" name="pass"><br>
    <input type="submit" name="submit" value="Go">
    </form>
<?php
doAdminFooter();
?>

<p id="footer">
<!-- share this button-->
<script type="text/javascript">var switchTo5x=true;</script>
<script type="text/javascript" src="http://w.sharethis.com/button/buttons.js"></script>
<script type="text/javascript">stLight.options({publisher: "", doNotHash: false, doNotCopy: false, hashAddressBar: false});</script>
    		        <span class='st_sharethis'></span>
			<span class='st_facebook'></span>
			<span class='st_twitter'></span>
			<span class='st_googleplus'></span>
			<span class='st_linkedin'></span>
			<span class='st_pinterest'></span>	
			<span class='st_email'></span>
<!-- end share this -->

<?php  
// simple unique hits counter
$countfile = 'counter.txt';
$ipfile = 'ip.txt';
$file = file($ipfile);
$hits = count($file); 
echo $hits;  
 function countint(){
   $ip = $_SERVER['REMOTE_ADDR'];
   global $countfile , $ipfile;

  if (!in_array($ip, file($ipfile, FILE_IGNORE_NEW_LINES))) {
  $current = (file_exists($countfile)) ? file_get_contents($countfile) : 0;
  file_put_contents($ipfile, $ip."\n", FILE_APPEND);
   file_put_contents($countfile, ++$current);

  }

   }

   countint();
  $value =file_get_contents($countfile);
?>

<br />
<br />

<style>
.modal {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1; /* Sit on top */
    padding-top: 100px; /* Location of the box */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}

/* Modal Content */
.modal-content {
    position: relative;
    background-color: #fefefe;
    margin: auto;
    padding: 0;
    border: 1px solid #888;
    width: 80%;
    box-shadow: 0 4px 8px 0 rgba(0,0,0,0.2),0 6px 20px 0 rgba(0,0,0,0.19);
    -webkit-animation-name: animatetop;
    -webkit-animation-duration: 0.4s;
    animation-name: animatetop;
    animation-duration: 0.4s
}

@-webkit-keyframes animatetop {
    from {top:-300px; opacity:0} 
    to {top:0; opacity:1}
}

@keyframes animatetop {
    from {top:-300px; opacity:0}
    to {top:0; opacity:1}
}

.close {
    color: white;
    float: right;
    font-size: 28px;
    font-weight: bold;
}

.close:hover,
.close:focus {
    color: #000;
    text-decoration: none;
    cursor: pointer;
}

.modal-header {
    padding: 2px 16px;
    background-color: orange;
    color: white;
}

.modal-body {padding: 2px 16px;}

.modal-footer {
    padding: 2px 16px;
    background-color: orange;
    color: white;
}
</style>

✞Боже, благослови този сайт. Хвала тебе! Амин.<br /> 

<a href="<?php echo $admin_url; ?>"><?php echo $admin_sitename; ?></a> | <a href="sign.php" target="_parent" title="Virtual Candle">Ligh a Candle</a> | <eti id="myBtn"><a href="#webmasters" title="Get the Source Code or Share Button">For Webmasters</a></eti> | <a href="http://eti.pw" target="_blank" title="Free Web Design and Free Web Hosting">ETI</a>

<div id="myModal" class="modal">

  <div class="modal-content">
    <div class="modal-header">
      <span class="close">×</span>
      <h2>For Webmasters:</h2>
    </div>
    <div class="modal-body">
Link to us! Please link to us!<br />
Here is our button for your website:<br /><p></p>
<img src="icons/virtualcandlebutton.jpg"/><br /><p></p>
Copy and Paste the code of the page you want in your site. That's all! Thank You!<br />
<small>Get the HTML code:</small><br />
<textarea style="color: orange; background-color: transparent" rows="6" onfocus="this.select()" onclick="this.select()" readonly>
<!-- BEGIN VIRTUAL CANDLE CODE-->
<a href="http://lightingacandle.pe.hu" title="Light a Candle" target="_blank"><img src="http://lightingacandle.pe.hu/icons/virtualcandlebutton.jpg"/></a><!-- END VIRTUAL CANDLE CODE-->
</textarea> 
<br />
<hr>
<br />
      <p><a href="http://lightingacandle.pe.hu/dnl.php?f=eti-lightingacandle-script.zip" title="Light a Candle Script" target="_blank">DOWNLOAD SOURCE CODE</a></p>
    </div>
    <div class="modal-footer">
      <h3>ETI</h3>
    </div>
  </div>

</div>

<script>
var modal = document.getElementById('myModal');
var btn = document.getElementById("myBtn");
var span = document.getElementsByClassName("close")[0];

btn.onclick = function() {
    modal.style.display = "block";
}

span.onclick = function() {
    modal.style.display = "none";
}

window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>

</p>
</div>

<!-- rand array with video audio from youtube.com -->
<?php
$a = array ('<iframe width="0" height="0" src="https://www.youtube.com/embed/B5GghnE8wi8?autoplay=1&loop=1" frameborder="0"></iframe>', '<iframe width="0" height="0" src="https://www.youtube.com/embed/ji_wmo2Q8CA?autoplay=1&loop=1" frameborder="0"></iframe>', '<iframe width="0" height="0" src="https://www.youtube.com/embed/VR-76YBisFc?autoplay=1&loop=1" frameborder="0"></iframe>', '<iframe width="0" height="0" src="http://loopvideos.com/NY-RLryio_8" frameborder="0"></iframe>');
$website = $a [rand(0, count($a) - 1)];
echo $website;
?>

<!-- i use these ytb links in array with music loop -->
<!-- <iframe width="0" height="0" src="https://www.youtube.com/embed/B5GghnE8wi8?autoplay=1&loop=1" frameborder="0"></iframe> -->
<!-- <iframe width="0" height="0" src="https://www.youtube.com/embed/ji_wmo2Q8CA?autoplay=1&loop=1" frameborder="0"></iframe> -->
<!-- <iframe width="0" height="0" src="https://www.youtube.com/embed/VR-76YBisFc?autoplay=1&loop=1" frameborder="0"></iframe> -->
<!-- <iframe width="0" height="0" src="https://www.youtube.com/embed/NY-RLryio_8?autoplay=1&loop=1" frameborder="0"></iframe> -->
<!-- <iframe width="0" height="0" src="http://youtubeloop.eti.pw/?v=NY-RLryio_8" frameborder="0"></iframe> -->

<!-- <iframe src='http://www.youtube.com/v/VIDEO_ID?autoplay=1&loop=1&playlist=VIDEO_ID' width='0' height='0' FRAMEBORDER=NO FRAMESPACING=0 BORDER=0 ></iframe> -->

</body>
</html>
<!-- www.eti.pw -->
